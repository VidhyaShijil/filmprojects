from django.contrib import admin
from . models import Addmovie


# Register your models here.
admin.site.register(Addmovie)